from django.shortcuts import render,redirect
from sportsapp.models import Player, UserType
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login

# Create your views here.
def index(request):
    return render(request,'index.html')

def reg(request):
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        password = request.POST['password']
        phone_number = request.POST['phone']

        address = request.POST['address']
        if User.objects.filter(email=email):
            return render(request, 'reg.html', {'message': "already added the email"})

        else:
            user = User.objects._create_user(username=email, password=password, email=email, first_name=name,
                                                 is_staff='0', last_name='1')
            user.save()
            stu = Player()
            stu.user = user
            stu.address= address
            stu.phone_number=phone_number
            stu.save()
            usertype = UserType()
            usertype.user = user
            usertype.type = "player"
            usertype.save()
            return render(request, 'reg.html', {'message': "successfully added"})
    return render(request,'reg.html')


def loginview(request):
    if request.method == 'POST':

        email = request.POST['email']
        password = request.POST['password']
        user = authenticate(username=email, password=password)

        if user is not None:
            login(request, user)
            if user.last_name == '1':
                if user.is_superuser:
                    return redirect('admin')
                elif UserType.objects.get(user_id=user.id).type =="player":
                    return redirect('player')  
            else:
                return render(request, 'login.html', {'message': " User Account Not Authenticated"})


        else:
            return render(request, 'login.html', {'message': "Invalid Username or Password"})
    
    return render(request,'login.html')

