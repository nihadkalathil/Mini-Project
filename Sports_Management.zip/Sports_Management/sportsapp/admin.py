from django.contrib import admin
from .models import Player
from django.db import models
# Register your models here.
admin.site.register(Player)

