from django.shortcuts import render,redirect,get_object_or_404
from .models import Achievement
from .forms import AchievementForm 
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .models import Injury
from .forms import InjuryUpdateForm


# Create your views here.
def index(request):
    return render(request,'player/player_index.html')



def view_achievements(request):
    player = request.user
    achievements = Achievement.objects.filter(player=player)
    return render(request, 'achievements.html', {'achievements': achievements})


@login_required
def view_achievements(request):
    user = request.user
    user_achievements = Achievement.objects.filter(player=user)
    
    # Fetch admin achievements (Assuming admin user has ID = 1, adjust as per your setup)
    admin_achievements = Achievement.objects.filter(player_id=1)  # Replace '1' with admin user's ID
    
    return render(request, 'achievements/achievements.html', {'user_achievements': user_achievements, 'admin_achievements': admin_achievements})



@login_required
def update_injury(request):
    if request.method == 'POST':
        form = InjuryUpdateForm(request.POST)
        if form.is_valid():
            injury = form.save(commit=False)
            injury.player = request.user  # Assign the logged-in user as the player
            injury.save()
            messages.success(request, 'Injury updated successfully!')
            return redirect('view_injury')
    else:
        form = InjuryUpdateForm()
    return render(request, 'update_injury.html', {'form': form})


@login_required
def view_injury(request):
    injuries = Injury.objects.filter(player=request.user)
    return render(request, 'view_injury.html', {'injuries': injuries})