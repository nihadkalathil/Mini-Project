
from django.urls import path
from playerapp import views

urlpatterns = [
    
        path('player',views.index,name='player'),
        path('achievements/', views.view_achievements, name='achievements'),
        path('update_injury/', views.update_injury, name='update_injury'),
        path('view_injury/', views.view_injury, name='view_injury'),
    

]
