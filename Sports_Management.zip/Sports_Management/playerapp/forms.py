# Inside your app's forms.py file (e.g., achievements/forms.py)

from django import forms
from .models import Achievement
from django.contrib.auth.models import User  # Assuming User is the user model in your project
from .models import Injury

class AchievementForm(forms.ModelForm):
    player = forms.ModelChoiceField(queryset=User.objects.all(), empty_label=None, required=True)
    achievement_text = forms.CharField(max_length=255, required=True)
    date_achieved = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}), required=True)

    class Meta:
        model = Achievement
        fields = ['player', 'achievement_text', 'date_achieved']

class InjuryUpdateForm(forms.ModelForm):
    class Meta:
        model = Injury
        fields = ['date', 'injury_update']