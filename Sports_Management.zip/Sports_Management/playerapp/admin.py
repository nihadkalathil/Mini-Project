from django.contrib import admin
from .models import Achievement
from .models import Injury

@admin.register(Achievement)
class AchievementAdmin(admin.ModelAdmin):
    list_display = ('player', 'achievement_text', 'date_achieved')
    list_filter = ('player', 'date_achieved')
    search_fields = ('player__username', 'achievement_text')

admin.site.register(Injury)