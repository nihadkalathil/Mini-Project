from django.db import models

from django.contrib.auth.models import User

class Achievement(models.Model):
    player = models.ForeignKey(User, on_delete=models.CASCADE)
    
    date_achieved = models.DateField()
    achievement_text = models.CharField(max_length=255)

    def __str__(self):
        return f"Achievement for {self.player.username}"
    
class Injury(models.Model):
    player = models.ForeignKey(User, on_delete=models.CASCADE)
    date = models.DateField()
    injury_update = models.TextField(blank=True)
    admin_reply = models.TextField(blank=True)

